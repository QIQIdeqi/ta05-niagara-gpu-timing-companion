TA15 / Frame 57: C0 versus C1Live
Python + Pillow required (python -m pip install Pillow).
python ta15-mask-compare.py reference.png candidate.png --threshold 30
Expected foreground counts: 729 and 718. Expected mask difference: 11 positions.
Images are from the previously published TA15 exercise.

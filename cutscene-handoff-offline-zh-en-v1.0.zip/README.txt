过场制作实践 02 · 接收方离线练习
双击 cutscene-handoff-exercise.html 开始。英文入口带 -en。
仅包含已公开的虚构交接练习、参考答案和无答案题面。

Open cutscene-handoff-exercise-en.html in your browser. The exercises, answers, and question sheet work offline.

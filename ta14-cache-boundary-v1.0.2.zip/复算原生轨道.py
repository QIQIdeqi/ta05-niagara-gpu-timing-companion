"""Verify native track ages and playback against each cache's own raw endpoints."""
import csv
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path

base = Path(__file__).resolve().parent

def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as source:
        return list(csv.DictReader(source))

def xyz(row):
    return tuple(float(row[key]) for key in ("x_cm", "y_cm", "z_cm"))

def positions(path, field):
    sets = defaultdict(dict)
    for row in rows(path):
        group = sets[row["condition"], int(row[field])]
        key = int(row["unique_id"])
        assert key not in group
        group[key] = xyz(row)
    assert all(len(group) == 32 for group in sets.values())
    return sets

reference = base / "缓存首帧参照.csv"
first_frame = Counter(xyz(row) for row in rows(reference) if row["cache_frame"] == "0")
assert sum(first_frame.values()) == 32

def verify(prefix, rate):
    raw = base / (prefix + "原始采样")
    log = (base / (prefix + "引擎.log")).read_text(encoding="utf-8-sig")
    match = re.search(r"TA14_SUBFRAME_DONE passed=1 output=.*?/TA12Probe/([0-9A-F]{32})", log)
    assert match, "Native sequence probe did not succeed"
    native_ages = {(int(pair), cond, int(sample)): (float(frame), float(display_rate), float(age))
                   for pair, cond, sample, frame, display_rate, age in re.findall(
                       r"TA14_SEQUENCE_AGE pair=(\d+) condition=([AB]) sample=(\d+) display_frame=([\d.]+) input_rate=([\d.]+) age=([\d.]+) bound=1", log)}
    outside = {(int(pair), cond) for pair, cond in re.findall(r"TA14_SEQUENCE_OUTSIDE pair=(\d+) condition=([AB]) active=0", log)}
    assert len(native_ages) == 22 and outside == {(pair, cond) for pair in (29,57) for cond in ("A","B")}
    report = {"engine_run_id":match[1],"display_rate":60,"tick_resolution":rate,
              "frame70_inactive_all_four_sequences":True,"samples":[]}
    for start in (29,57):
        pair = raw / f"frames_{start}_{start+1}"
        endpoints = positions(pair / "subframe_endpoints.csv", "frame")
        assert all(endpoints["A", frame] == endpoints["B", frame] for frame in (start,start+1))
        observed = positions(pair / "subframe_positions.csv", "sample")
        states = rows(pair / "subframe_states.csv")
        assert len(states) == (10 if start == 29 else 12)
        for state in states:
            cond = state["condition"]
            sample = int(state["sample"])
            frame, display_rate, actual_age = native_ages[start, cond, sample]
            cache_start = float(state["cache_start_s"])
            duration = float(state["cache_duration_s"])
            assert display_rate == 60 and math.isclose(frame, start+float(state["nominal_fraction"]), abs_tol=5e-6)
            assert math.isclose(actual_age, float(state["request_s"]), abs_tol=1e-8)
            points = observed.get((cond,sample),{})
            result = {"condition":cond,"display_frame":frame,"track_requested_age_s":actual_age,"particle_count":len(points)}
            if frame == 58 and rate == 24000:
                assert math.isclose(actual_age, cache_start, abs_tol=1e-6)
                assert Counter(points.values()) == first_frame
                assert state["active"] == "1" and state["complete"] == "0"
                result["observed"] = "repeat_to_first_cache_frame"
            elif frame == 58 and not points:
                assert rate == 60 and float(state["quantized_s"]) > cache_start + duration
                assert state["active"] == "0" and state["complete"] == "1"
                result["observed"] = "cache_age_past_end_completed"
            else:
                assert state["active"] == "1" and state["complete"] == "0"
                assert math.isclose(actual_age, cache_start+frame/60, abs_tol=1e-6)
                left, right = (endpoints[cond, k] for k in (start,start+1))
                assert points.keys() == left.keys() == right.keys()
                fraction = float(state["effective_fraction"])
                if cond == "A":
                    expected = right if fraction > .5 else left
                    assert points == expected
                    result["observed"] = "right_endpoint" if fraction > .5 else "left_endpoint"
                else:
                    residual = max(math.dist(points[k],tuple(x+(y-x)*fraction for x,y in zip(left[k],right[k])))
                                   for k in points)
                    assert residual < 1e-4, (frame,residual)
                    result["linear_position_residual_cm"] = residual
                    result["observed"] = "position_matches_linear_model"
                result["effective_fraction"] = fraction
            report["samples"].append(result)
    return report

reports = [verify("原生轨道",24000)]
if (base / "原生轨道_60tick_原始采样").is_dir():
    reports.append(verify("原生轨道_60tick_",60))
result = {"runs":reports,"verified_native_states":sum(len(r["samples"]) for r in reports),
          "verified_position_rows":sum(s["particle_count"] for r in reports for s in r["samples"])}
(base / "原生轨道核验.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
for run in reports:
    print(run["tick_resolution"],[(s["condition"],s["track_requested_age_s"],s["observed"])
                                  for s in run["samples"] if s["display_frame"]==58])


import csv
from collections import Counter
from pathlib import Path

from 核对缓存帧 import compare, read_positions

root = Path(__file__).resolve().parent
steps = [2, 31, 59]

for index in range(1, 4):
    run = root / "冻结复测" / f"第{index}轮"
    frames = compare(run)
    assert frames["all_exact_at_recorded_precision"]
    live = read_positions(run / "positions.csv", "snapshot_tick")
    for name, expected_ticks in (("playback", [1, 2, 3]), ("recompute", steps)):
        points = read_positions(run / f"{name}_positions.csv", "snapshot_tick")
        assert sorted(points) == steps
        with (run / f"{name}_state.csv").open(encoding="utf-8-sig", newline="") as source:
            state = list(csv.DictReader(source))
        assert [int(row["source_step"]) for row in state] == steps
        assert [int(row["component_tick"]) for row in state] == expected_ticks
        for step, row in zip(steps, state):
            assert Counter(live[step]) == Counter(points[step])
            expected_age = frames["frames"][step - 2]["reported_live_age_s"]
            assert float(row["desired_age_s"]) == expected_age
            assert abs(float(row["observed_age_s"]) - expected_age) <= 1e-5
            assert row["active"] == "1" and row["complete"] == "0"
    print(f"Round {index}: {frames['cache_frames']} frames, {frames['points_per_source']} XYZ, 3 path comparisons PASS")

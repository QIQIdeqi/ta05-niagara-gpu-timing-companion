"""Compare live CPU Niagara positions with the Sim Cache points read in the same run."""
import csv
import json
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path


def read_positions(path, step_column):
    points = defaultdict(list)
    with path.open(newline='', encoding='utf-8-sig') as source:
        for row in csv.DictReader(source):
            step = int(row[step_column])
            if 'cache_frame' in row:
                assert int(row['cache_frame']) == step - 2
            position = tuple(float(row[axis]) for axis in ('x_cm', 'y_cm', 'z_cm'))
            assert all(map(math.isfinite, position))
            points[step].append(position)
    return points


def compare(run):
    live = read_positions(run / 'positions.csv', 'snapshot_tick')
    cache = read_positions(run / 'cache_positions.csv', 'simulation_step')
    assert sorted(live) == sorted(cache) == list(range(2, 61))
    with (run / 'ticks.csv').open(newline='', encoding='utf-8-sig') as source:
        ticks = {int(row['step']): row for row in csv.DictReader(source)}
    assert sorted(ticks) == list(range(1, 61))
    assert all(int(row['tick_after']) == step for step, row in ticks.items())

    frames = []
    for step, live_points in sorted(live.items()):
        cached_points = cache[step]
        assert len(live_points) == len(cached_points) == 32
        distances = [
            min(math.dist(point, other) for other in other_points)
            for points, other_points in ((live_points, cached_points), (cached_points, live_points))
            for point in points
        ]
        frames.append({
            'cache_frame': step - 2,
            'simulation_step': step,
            'reported_live_age_s': float(ticks[step]['age_after']),
            'points_each': len(live_points),
            'exact_xyz_multiset_intersection': sum((Counter(live_points) & Counter(cached_points)).values()),
            'mean_symmetric_nearest_cm': math.fsum(distances) / len(distances),
            'max_symmetric_nearest_cm': max(distances),
        })
    return {
        'cache_frames': len(frames),
        'points_per_source': sum(frame['points_each'] for frame in frames),
        'all_exact_at_recorded_precision': all(frame['exact_xyz_multiset_intersection'] == frame['points_each'] for frame in frames),
        'maximum_nearest_error_cm': max(frame['max_symmetric_nearest_cm'] for frame in frames),
        'frames': frames,
        'cache_component_playback_tested': False,
        'cache_asset_save_reopen_tested': False,
        'sequencer_tested': False,
    }


if __name__ == '__main__':
    print(json.dumps(compare(Path(sys.argv[1])), ensure_ascii=False, indent=2))
